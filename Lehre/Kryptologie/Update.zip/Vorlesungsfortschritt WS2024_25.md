### 30. 09. 2024
- Kapitel 1 Einführung abgeschlossen
- Sektion 2.1 Algebraische Grundlagen abgeschlossen
- Sektion 2.2 bis Äquivalenzrelation über den ganzen Zahlen abgeschlossen

#### Aufgaben bis zum 17.10.
- **<span style="color:#f7b8ff">Restliches 2. Kapitel bearbeiten</span>**
- Übungen bearbeiten (für die Praktika)
- Prüfen ob ihr die Beispiele auch selbst berechnen könntest (vor allem ab 2.3)
- Fragen für die Vorlesung vorbereiten, im besten Fall bereits im Chat teilen


### 17. 10. 2024
- Kapitel 2 Algebraische und Zahlentheoretische Grundlagen abgeschlossen
- Angebot für 28.10.2024 als Konsultationstermin
- Kapitel 4 übernehme ich selbst für den Freitag 25.10.2024

#### Aufgaben bis zum 24.10.
- **<span style="color:#f7b8ff">Für die nächste Vorlesung Kapitel 3 vorbereiten(!)</span>**
- Grundlagen Python für das Praktikum grob ansehen:
	- variablen definieren
	- arrays bzw. listen
	- if/else
	- schleifen
	- list comprehension
	- funktionen

### 24. 10. 2024
- Kapitel 3 abgeschlossen (RSA, RSA Beweis, Schnelle Modulare Exponentiation)
- Einführung in Python und Sage
- Aufgabenblätter 1 und 2 an die Gruppe verteilt

### 25. 10. 2024
- Kapitel 4 abgeschlossen (Chinesischer Restsatz, Angriffe auf RSA)

#### Aufgaben bis zum 07.11.
- **<span style="color:#f7b8ff">Kapitel 5 vorbereiten</span>**
- Aufgabenblatt 1 für das Praktikum absolvieren

### 07. 11. 2024

- Kapitel 5 abgeschlossen

### 14.11.2024

- Kapitel 6 abgeschlossen

### 28. 11. 2024

- Kapitel 7 abgeschlossen

Aufgaben zum 05.12.2024
- Kapitel 8 vorbereiten, Kontrollfragen abchecken
- Praktikum bearbeiten

### 05. 12. 2024

### 12. 12. 2024

### 19. 12. 2024

### 09. 01. 2025

### 16. 01. 2024

### 23. 01. 2024